package Attendance;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Home extends Common{
	
	public void homeView(int id) throws SQLException {
		final JFrame frame = new JFrame();
		Font button = new Font("Poppin", Font.BOLD, 20);
		final Admin adm = new Admin();
		
		
		//-LOGOUT BUTTON
    
        logoutButton.setBounds(30, 7, 80, 20);
        logoutButton.setFont(new Font("Poppins", Font.BOLD, 12));
        logoutButton.setBackground(Color.decode("#0000"));
        logoutButton.setForeground(Color.decode("#FFFFFF"));
        frame.add(logoutButton);
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); 
                Login login = new Login();
                login.loginView();
            }
        });
		
		//CLOSE
		x.setForeground(Color.decode("#37474F"));
		x.setBounds(965, 10, 100, 20);
		x.setFont(new Font("Poppins", Font.BOLD, 20));
		frame.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		
		
		//Panel-
		panel.setBounds(0, 0, 1000, 35);
		panel.setBackground(Color.decode("#FFFFFF"));
		frame.add(panel);
		
		
		//STUDENTS
		JButton students = new JButton("ADD STUDENTS");
		students.setBounds(130, 135, 300, 40);
		students.setFont(button);
		students.setBackground(Color.decode("#FFFFFF"));
		students.setForeground(Color.decode("#37474F"));
		students.setFont(new Font("Poppin", Font.BOLD, 15));
		frame.add(students);
		students.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Students std = new Students();
				try {
					std.studentView();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		
		//ADDATTENDANCE
		JButton addattendance = new JButton("ADD ATTENDANCE");
		addattendance.setBounds(130, 260, 300, 40);
		addattendance.setFont(button);
		addattendance.setBackground(Color.decode("#FFFFFF"));
		addattendance.setForeground(Color.decode("#37474F"));
		addattendance.setFont(new Font("Poppins", Font.BOLD, 15));
		frame.add(addattendance);
		addattendance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AddAttendance addattend = new AddAttendance();
				try {
					addattend.addView();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		//EDITATTENDANCE
		JButton editattendance = new JButton("EDIT ATTENDANCE");
		editattendance.setBounds(580, 135, 300, 40);
		editattendance.setFont(button);
		editattendance.setBackground(Color.decode("#FFFFFF"));
		editattendance.setForeground(Color.decode("#37474F"));
		editattendance.setFont(new Font("Poppins", Font.BOLD, 15));
		frame.add(editattendance);
		editattendance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EditAttendance editattend = new EditAttendance();
				try {
					editattend.editView();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		//TEACHERS
		JButton teacher = new JButton("ADD TEACHERS");
		teacher.setBounds(130, 385, 300, 40);
		teacher.setFont(new Font("Poppins", Font.BOLD, 15));
		teacher.setBackground(Color.decode("#FFFFFF"));
		teacher.setForeground(Color.decode("#37474F"));
		frame.add(teacher);
		teacher.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Teachers teacher = new Teachers();
				try {
					teacher.teachersView();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		//ADMIN
		JButton admin = new JButton("ADD ADMIN");
		admin.setBounds(580, 385, 300, 40);
		admin.setFont(new Font("Poppins", Font.BOLD, 15));
		admin.setBackground(Color.decode("#FFFFFF"));
		admin.setForeground(Color.decode("#37474F"));
		frame.add(admin);
		admin.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					adm.adminView();
				} 
				catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		//CLASS
		JButton classes = new JButton("ADD CLASS");
		classes.setBounds(580, 260, 300, 40);
		classes.setFont(new Font("Poppins", Font.BOLD, 15));
		classes.setBackground(Color.decode("#FFFFFF"));
		classes.setForeground(Color.decode("#37474F"));
		frame.add(classes);
		classes.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Class classroom = new Class();
				classroom.classView();
			}
		});
		
		
		frame.setSize(1000,600);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);  
		frame.setVisible(true);
		frame.setFocusable(true);
		frame.getContentPane().setBackground(Color.decode("#25CEDE"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public String getUser(int id) throws SQLException {
	    //ENTER PORT, USER, PASSWORD.
		String url = "jdbc:mysql://localhost:3306/attendance";
		String user = "root";
		String pass = "5Z1x2ytpps@";
		Connection con = DriverManager.getConnection(url, user, pass);
		String str = "SELECT name FROM user WHERE id = "+id;
		Statement stm = con.createStatement();
		ResultSet rst = stm.executeQuery(str);
		rst.next();
		return rst.getString("name");
	}
}
