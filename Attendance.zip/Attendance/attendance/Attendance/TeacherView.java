package Attendance;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TeacherView extends Common{
	public void tcView(int id) throws SQLException {
		
		final JFrame frame = new JFrame();
		Font btn = new Font("Poppins", Font.BOLD, 14);
		
		  //LOGOUT BUTTON
      
        logoutButton.setBounds(30, 7, 80, 20);
        logoutButton.setFont(new Font("Poppins", Font.BOLD, 12));
        logoutButton.setBackground(Color.decode("#0000"));
        logoutButton.setForeground(Color.decode("#FFFFFF"));
        frame.add(logoutButton);
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose(); // Close the current frame (StudentView)
                // Create a new instance of your login frame and show it
                Login login = new Login();
                login.loginView();
            }
        });
		
		//CLOSE

		x.setForeground(Color.decode("#37474F"));
		x.setBounds(965, 10, 100, 20);
		x.setFont(new Font("Times New Roman", Font.BOLD, 20));
		frame.add(x);
		x.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		
				
		//MINIMIZE
		JLabel min = new JLabel("_");
		min.setForeground(Color.decode("#37474F"));
		min.setBounds(935, 0, 100, 20);
		frame.add(min);
		min.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
		
		
		//Panel
		
		panel.setBounds(0, 0, 1000, 35);
		panel.setBackground(Color.decode("#FFFFFF"));
		frame.add(panel);
		
		
		JLabel welcome = new JLabel("Welcome "+getUser(id)+",");
		welcome.setForeground(Color.decode("#FFFFFF"));
		welcome.setBounds(10, 50, 250, 20);
		welcome.setFont(new Font("Poppins", Font.PLAIN, 16));
		frame.add(welcome);


		
		JButton addattendance = new JButton("ADD ATTENDANCE");
		addattendance.setBounds(350, 200, 300, 40);
		addattendance.setFont(btn);
		addattendance.setBackground(Color.decode("#FFFFFF"));
		addattendance.setForeground(Color.decode("#0000"));
		frame.add(addattendance);
		addattendance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AddAttendance addatt = new AddAttendance();
				try {
					addatt.addView();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		JButton editattendance = new JButton("EDIT ATTENDANCE");
		editattendance.setBounds(350, 350, 300, 40);
		editattendance.setFont(btn);
		editattendance.setBackground(Color.decode("#FFFFFF"));
		editattendance.setForeground(Color.decode("#0000"));
		frame.add(editattendance);
		editattendance.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EditAttendance editatt = new EditAttendance();
				try {
					editatt.editView();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		frame.setSize(1000,600);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setUndecorated(true);
		frame.setLocationRelativeTo(null);  
		frame.setVisible(true);
		frame.setFocusable(true);
		frame.getContentPane().setBackground(Color.decode("#25CEDE"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public String getUser(int id) throws SQLException {
	    //ENTER PORT, USER, PASSWORD.
		String url = "jdbc:mysql://localhost:3306/attendance";
		String user = "root";
		String pass = "5Z1x2ytpps@";
		Connection con = DriverManager.getConnection(url, user, pass);
		String str = "SELECT name FROM user WHERE id = "+id;
		Statement stm = con.createStatement();
		ResultSet rst = stm.executeQuery(str);
		rst.next();
		return rst.getString("name");
	}
}